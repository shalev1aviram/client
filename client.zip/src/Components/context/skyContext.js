import { createContext } from "react";

const skyContext = createContext();

export default skyContext;