import { createContext } from "react";

const flyContext = createContext();

export default flyContext;