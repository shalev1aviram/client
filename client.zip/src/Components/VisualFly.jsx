import React, { useEffect, useState } from 'react'
import axios from 'axios'
import Loading from '../shared/Loading'
import { useNavigate } from 'react-router-dom'
import { CgArrowLongUp } from 'react-icons/cg';

const VisualFly = ({ sky }, allBlue, allGreen) => {
    const [ground, setGround] = useState(100 - sky);
    console.log(sky);
    console.log(ground);
    useEffect(() => {
        setGround(100 - sky);
    }, [sky])

    if (sky == 100) {
        allBlue = "bg-blue-500"
    }
    if (sky == 0) {
        allGreen = "bg-green-500"
    }


    return (
        <div>
            <div className='flex flex-col items-center md:flex md:flex-row md:justify-center md:items-center md:mb-10 md:mt-10'>
                <div className='Altitud my-5 h-[500px] w-[200px] border border-black md:mr-10'>
                    <ul className='flex flex-col items-center '>
                        <li>3000</li>
                        <li className='mt-[3.3rem]'>2500</li>
                        <li className='mt-[3.3rem]'>2000</li>
                        <li className='mt-[3.3rem]'>1500</li>
                        <li className='mt-[3.3rem]'>1000</li>
                        <li className='mt-[3.3rem]'>500</li>
                        <li className='mt-[3.3rem]'>0</li>
                    </ul>
                </div>

                <div className='HIS my-5 h-[400px] w-[400px] rounded-full border border-black md:mr-10'>
                    <ul className=''>
                        <li className='flex justify-center'>0</li>
                        <div className='flex justify-between mt-[150px] px-5'>
                            <li>270</li>
                            <CgArrowLongUp size="4rem" color="black" />

                            <li>180</li>
                        </div>
                        <li className='flex justify-center mt-[120px]'>90</li>
                    </ul>
                </div>

                <div className={`ADI ${allBlue} ${allGreen} overflow-hidden flex flex-col justify-center my-5 h-[400px] w-[400px] rounded-full border border-black`}>
                    <div className='h-full'>
                        <div className={`bg - blue - 700 h-[${sky}%] `}></div>
                        <div className={`bg - green - 700 h-[${ground}%] `}></div>
                    </div>
                </div >
            </div >
        </div >
    )
}

export default VisualFly