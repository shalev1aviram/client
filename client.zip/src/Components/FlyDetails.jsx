import React, { useContext, useState } from 'react'
import axios from 'axios'
import Loading from '../shared/Loading'
import { useForm } from 'react-hook-form'
import flyContext from './context/flyContext'
import { useNavigate } from 'react-router-dom'
import { REGISTER_FLY_URL } from '../Routes/urls'
import { getAxiosStatus } from '../utils/utils'


const FlyDetails = () => {
    const { flyData, setflyData } = useContext(flyContext)
    const { register, handleSubmit, setError, formState: { errors, isSubmitting } } = useForm({
        mode: "onSubmit",
        reValidateMode: "onChange"
    });


    //              !!!Player לזכור להעביר את זה ואת הגט אקסיוס סטטוס לקומפוננטה האחרונה שמציגה את ה 

    const nav = useNavigate()
    const signup = async (data) => {
        const detailsUpdate = data
        console.log("update: ", detailsUpdate);
        setflyData({ ...flyData, ...detailsUpdate })
        try {
            await axios.post(REGISTER_FLY_URL, data)
            nav("/visualFly")
        } catch (error) {
            if (getAxiosStatus(error) == 409) {
                setError("error", { message: "Altitude is already exist" })
            }
            else {
                console.log(getAxiosStatus(error) + ": ", error);
                setError("error", { message: "network error" })
            }
        }
    }


    return (
        <>
            <Loading on={isSubmitting} />
            <div className="max-w-sm mx-auto mt-8 bg-gradient-to-r from-slate-300 via-slate-400 to-slate-500 rounded-lg">
                <form onSubmit={handleSubmit(signup)} className=" shadow-md rounded px-8 pt-6 pb-3 mb-4 items-center">
                    <div className='w-full text-center'><h1 className='text-black font-medium text-3xl pb-2'>Start Fly</h1></div>
                    <div className="mb-4 pb-2 border-b-2 border-black shadow-md p-1 pt-3 rounded">
                        <label className="ps-1 block text-gray-700 text-sm font-bold ">
                            Altitude (0-3000)
                        </label>
                        <input
                            type='number'
                            className="bg-transparent appearance-none border-none w-full px-3 pt-2 pb-1 text-gray-700 focus:border-none focus:outline-none"
                            {...register("Altitude", {
                                required: true,
                                validate: (value) => {
                                    if ((value < 0)) return "Altitude most be Minimum 0"
                                    if ((value > 3000)) return "Altitude cant reach 3000"
                                }
                            })}
                        />
                    </div>
                    <div className='min-h-9 text-center pb-2'>{errors.Altitude && <span className='text-xs text-red-700'>{errors.Altitude.message}</span>}</div>
                    <div className="mb-4 pb-2 border-b-2 border-black shadow-md p-1 pt-3 rounded">
                        <label className="ps-1 block text-gray-700 text-sm font-bold ">
                            His (0-360)
                        </label>
                        <input
                            type="number"
                            className="bg-transparent appearance-none border-none w-full px-3 pt-2 pb-1 text-gray-700 focus:border-none focus:outline-none"
                            {...register("His", {
                                required: true,
                                validate: (value) => {
                                    if ((value < 0)) return "His most be Minimum 0"
                                    if ((value > 360)) return "His cant reach 360"
                                }
                            })}
                        />
                    </div>
                    <div className='min-h-9 text-center pb-2'>{errors.His && <span className='text-xs text-red-700'>{errors.His.message}</span>}</div>
                    <div className="mb-4 pb-2 border-b-2 border-black shadow-md p-1 pt-3 rounded">
                        <label className="ps-1 block text-gray-700 text-sm font-bold ">
                            ADI (0-100)
                        </label>
                        <input
                            type="number"
                            className="bg-transparent appearance-none border-none w-full px-3 pt-2 pb-1 text-gray-700 focus:border-none focus:outline-none"
                            {...register("ADI", {
                                required: true,
                                validate: (value) => {
                                    if ((value < 0)) return "ADI most be Minimum 0"
                                    if ((value > 100)) return "ADI cant reach 100"
                                }
                            })}
                        />
                    </div>
                    <div className='min-h-9 text-center pb-2'>{errors.ADI && <span className='text-xs text-red-700'>{errors.ADI.message}</span>}</div>
                    <div className="mb-2 pb-2 text-center w-full">
                        <button type="submit" className="bg-gradient-to-r from-slate-400 via-gray-400 to-slate-400 shadow-lg text-black hover:scale-110 transition duration-300 ease-in-out font-bold py-2 px-5 rounded focus:outline-none focus:shadow-outline">
                            Submit
                        </button>
                    </div>
                    {errors.error && <span className='text-red-600'>{errors.error.message}</span>}
                </form>
            </div>
        </>
    )
}
export default FlyDetails


FlyDetails.jsx




