const BASE_URL="http://localhost:3001/"


//user routs
const REGISTER_FLY_URL="fly/addFly"


export{BASE_URL as default,REGISTER_FLY_URL}