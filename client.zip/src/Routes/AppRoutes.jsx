import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Home from '../Components/Home'
import Navbar from '../Components/Navbar'
import FlyDetails from '../Components/FlyDetails'
import VisualFly from '../Components/VisualFly'


const AppRoutes = () => {
    return (
        <Routes>
            <Route path='/' element={<Navbar />}>
                <Route path='/' element={<Home />} />
                <Route path='/flyDetails' element={<FlyDetails/>} />
                <Route path='/visualFly' element={<VisualFly/>} />
                <Route path='*' element={<h1 className='text-4xl'>404 not found</h1>} />
            </Route>
        </Routes>
    )
}

export default AppRoutes