import { BrowserRouter } from 'react-router-dom'
import './App.css'
import AppRoutes from './Routes/AppRoutes'
import { useState, useEffect } from 'react'
import flyContext from './Components/context/flyContext'
import skyContext from './Components/context/skyContext'


function App() {
  const [skyData, setSkyData] = useState({})
  const [flyData, setflyData] = useState({})

  useEffect(() => {
    console.log("skyData: ", skyData)
  }, [skyData])

  useEffect(() => {
    console.log("flyData: ", flyData)
  }, [flyData])


  return (
    <flyContext.Provider value={{
      flyData,
      setflyData
    }}>
      <skyContext.Provider value={{
        skyData,
        setSkyData
      }}>

        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>

      </skyContext.Provider>
    </flyContext.Provider>
  )
}

export default App
